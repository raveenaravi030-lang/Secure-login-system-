// Small UX helpers only. Security is enforced on the SERVER, never here.
document.querySelectorAll(".toggle-pw").forEach(function (btn) {
  btn.addEventListener("click", function () {
    var input = document.getElementById(btn.dataset.target);
    var show = input.type === "password";
    input.type = show ? "text" : "password";
    btn.textContent = show ? "Hide" : "Show";
  });
});

var pw = document.getElementById("password");
var bar = document.getElementById("meter-bar");
if (pw && bar) {
  var rules = {
    length: function (v) { return v.length >= 8; },
    lower:  function (v) { return /[a-z]/.test(v); },
    upper:  function (v) { return /[A-Z]/.test(v); },
    digit:  function (v) { return /\d/.test(v); },
    special: function (v) { return /[^A-Za-z0-9]/.test(v); }
  };
  var text = document.getElementById("meter-text");
  pw.addEventListener("input", function () {
    var score = 0;
    Object.keys(rules).forEach(function (key) {
      var li = document.querySelector('[data-rule="' + key + '"]');
      var ok = rules[key](pw.value);
      li.classList.toggle("ok", ok);
      if (ok) score++;
    });
    var colors = ["#dc2626", "#dc2626", "#f59e0b", "#f59e0b", "#84cc16", "#16a34a"];
    var labels = ["Very weak", "Very weak", "Weak", "Fair", "Good", "Strong"];
    bar.style.width = (score / 5 * 100) + "%";
    bar.style.background = colors[score];
    text.textContent = pw.value ? labels[score] : "Password strength";
  });
}
