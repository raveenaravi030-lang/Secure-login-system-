# Simple Explanation for Presentation

**One-line summary:** "A website where people register and log in, and where passwords are never stored in readable form, and common attacks are blocked."

## File by file
- **config.py** – settings: secret key from environment, cookie safety, lockout numbers.
- **schema.sql / db.py** – make the database and tables automatically; open one connection per request and always close it.
- **app.py** – the brain:
  - `validate_registration()` checks username and password rules.
  - `register()` hashes the password, saves it with a `?` query, catches duplicates.
  - `login()` checks lockout, finds the user, checks the hash, starts a session.
  - `login_required` blocks the dashboard unless logged in.
  - `verify_csrf()` rejects forms without the secret token.
  - `set_security_headers()` adds browser protections.
- **templates/** – the pages (base layout + register, login, dashboard, error).
- **static/** – CSS design and a small JS file for show/hide password and strength meter.
- **test_app.py** – 15 automatic tests proving the features work.

## Key ideas in plain words
1. **Hashing** – like a meat grinder: easy to grind, impossible to turn back. We store the ground result; to check a login we grind the typed password and compare. Salt makes the same password grind differently for each user.
2. **Parameterized queries** – the `?` keeps user text as plain data so `' OR '1'='1` is just a strange name, not a command.
3. **Session** – after login the server gives the browser a signed ID card (cookie). Each page checks the card.
4. **CSRF token** – a secret code printed in our forms. A malicious site can't see it, so it can't submit forms for you.
5. **Rate limiting** – 5 wrong tries in 5 minutes and the account/IP is paused.
6. **Generic error** – "Invalid username or password" never tells attackers which part was wrong.

## Demo script (3 minutes)
1. Register with a weak password → show errors. Register properly.
2. Try same username → duplicate error.
3. Log in wrongly 5 times → lockout message.
4. (Restart/wait or use another account) log in correctly → dashboard.
5. Log out, press Back, open /dashboard → redirected.
6. Open DB with `sqlite3` → show hashes, not passwords.
7. Run `python -m unittest -v` → 15 OK.

## Likely teacher questions
- *Why not encrypt passwords?* Encryption can be reversed with a key; hashes can't.
- *Why POST for logout?* So other sites can't log you out via a link.
- *What would you add next?* HTTPS, MFA, email verification, Flask-Limiter.
