"""Secure Login System - Flask application."""
import hmac
import re
import secrets
import sqlite3
import time
from functools import wraps

from flask import (Flask, abort, flash, g, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import db

app = Flask(__name__)
app.config.from_object("config")
db.init_db(app)

# A fake hash used so "unknown user" logins take as long as "wrong password"
# ones. This stops attackers from discovering which usernames exist by timing.
DUMMY_HASH = generate_password_hash("not-a-real-password")

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]+$")


# ---------------------------------------------------------------------------
# CSRF protection
# ---------------------------------------------------------------------------
def get_csrf_token():
    """Create a random token once per session and return it."""
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(32)
    return session["csrf_token"]


app.jinja_env.globals["csrf_token"] = get_csrf_token


@app.before_request
def verify_csrf():
    """Reject any POST whose hidden form token doesn't match the session's."""
    if request.method == "POST":
        sent = request.form.get("csrf_token", "").encode()
        expected = session.get("csrf_token", "").encode()
        # compare_digest is constant-time, so it can't leak info via timing
        if not expected or not hmac.compare_digest(sent, expected):
            abort(400, description="Invalid or missing CSRF token. Please reload the page and try again.")


# ---------------------------------------------------------------------------
# Security headers
# ---------------------------------------------------------------------------
@app.after_request
def set_security_headers(response):
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self'; style-src 'self'; "
        "img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'self'"
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    # Don't let the browser cache pages (so Back button can't show the
    # dashboard after logout).
    response.headers["Cache-Control"] = "no-store"
    return response


# ---------------------------------------------------------------------------
# Authentication helpers
# ---------------------------------------------------------------------------
def login_required(view):
    """Decorator: only logged-in users may open the page."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        user_id = session.get("user_id")
        user = None
        if user_id is not None:
            user = db.get_db().execute(
                "SELECT id, username, created_at FROM users WHERE id = ?", (user_id,)
            ).fetchone()
        if user is None:
            session.clear()
            flash("Please log in to access that page.", "error")
            return redirect(url_for("login"))
        g.user = user
        return view(*args, **kwargs)
    return wrapped


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def validate_registration(username, password, confirm):
    cfg = app.config
    errors = []
    if not (cfg["USERNAME_MIN"] <= len(username) <= cfg["USERNAME_MAX"]):
        errors.append(f"Username must be {cfg['USERNAME_MIN']}-{cfg['USERNAME_MAX']} characters long.")
    elif not USERNAME_RE.match(username):
        errors.append("Username may only contain letters, numbers and underscores.")

    if len(password) < cfg["PASSWORD_MIN"]:
        errors.append(f"Password must be at least {cfg['PASSWORD_MIN']} characters long.")
    if len(password) > cfg["PASSWORD_MAX"]:
        errors.append(f"Password must be at most {cfg['PASSWORD_MAX']} characters long.")
    if not re.search(r"[a-z]", password):
        errors.append("Password needs at least one lowercase letter.")
    if not re.search(r"[A-Z]", password):
        errors.append("Password needs at least one uppercase letter.")
    if not re.search(r"\d", password):
        errors.append("Password needs at least one number.")
    if not re.search(r"[^A-Za-z0-9]", password):
        errors.append("Password needs at least one special character (e.g. ! @ # $).")
    if username and username.lower() in password.lower():
        errors.append("Password must not contain your username.")
    if password != confirm:
        errors.append("Passwords do not match.")
    return errors


# ---------------------------------------------------------------------------
# Brute-force protection (rate limiting)
# ---------------------------------------------------------------------------
def lockout_seconds_left(username, ip):
    """Return seconds of lockout remaining (0 if the user may try)."""
    conn = db.get_db()
    now = int(time.time())
    window_start = now - app.config["LOCKOUT_SECONDS"]
    # Housekeeping: forget old attempts
    conn.execute("DELETE FROM login_attempts WHERE attempted_at < ?", (window_start,))
    conn.commit()
    rows = conn.execute(
        "SELECT attempted_at FROM login_attempts "
        "WHERE username = ? AND ip_address = ? AND attempted_at >= ? "
        "ORDER BY attempted_at ASC",
        (username.lower(), ip, window_start),
    ).fetchall()
    if len(rows) >= app.config["MAX_FAILED_ATTEMPTS"]:
        return max(1, rows[0]["attempted_at"] + app.config["LOCKOUT_SECONDS"] - now)
    return 0


def record_failed_attempt(username, ip):
    conn = db.get_db()
    conn.execute(
        "INSERT INTO login_attempts (username, ip_address, attempted_at) VALUES (?, ?, ?)",
        (username.lower(), ip, int(time.time())),
    )
    conn.commit()


def clear_attempts(username, ip):
    conn = db.get_db()
    conn.execute(
        "DELETE FROM login_attempts WHERE username = ? AND ip_address = ?",
        (username.lower(), ip),
    )
    conn.commit()


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return redirect(url_for("dashboard" if "user_id" in session else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        errors = validate_registration(username, password, confirm)
        if errors:
            for e in errors:
                flash(e, "error")
            return render_template("register.html", username=username), 400

        # scrypt (Werkzeug default) + random salt, built in
        password_hash = generate_password_hash(password)
        try:
            conn = db.get_db()
            # Parameterized query: ? placeholders keep user input as DATA, never SQL
            conn.execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                (username, password_hash),
            )
            conn.commit()
        except sqlite3.IntegrityError:  # UNIQUE constraint -> duplicate username
            flash("That username is already taken. Please choose another.", "error")
            return render_template("register.html", username=username), 409

        flash("Account created successfully! You can now log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html", username="")


@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        ip = request.remote_addr or "unknown"

        wait = lockout_seconds_left(username, ip)
        if wait:
            minutes = (wait + 59) // 60
            flash(f"Too many failed attempts. Try again in about {minutes} minute(s).", "error")
            return render_template("login.html", username=username), 429

        user = db.get_db().execute(
            "SELECT id, username, password_hash FROM users WHERE username = ?",
            (username,),
        ).fetchone()

        # Always run one hash check (real or dummy) so timing is similar
        hash_to_check = user["password_hash"] if user else DUMMY_HASH
        password_ok = check_password_hash(hash_to_check, password)

        if user and password_ok:
            clear_attempts(username, ip)
            session.clear()                 # new session -> prevents session fixation
            session.permanent = True        # uses the 30-minute lifetime
            session["user_id"] = user["id"]
            flash("Logged in successfully.", "success")
            return redirect(url_for("dashboard"))

        record_failed_attempt(username, ip)
        # Same message whether the username or the password was wrong
        flash("Invalid username or password.", "error")
        return render_template("login.html", username=username), 401

    return render_template("login.html", username="")


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", user=g.user)


@app.route("/logout", methods=["POST"])   # POST + CSRF token: other sites can't log you out
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Error pages (never show stack traces to users)
# ---------------------------------------------------------------------------
@app.errorhandler(400)
@app.errorhandler(404)
@app.errorhandler(405)
@app.errorhandler(413)
@app.errorhandler(500)
def handle_error(error):
    code = getattr(error, "code", 500)
    message = getattr(error, "description", "Something went wrong.") if code != 500 else "Something went wrong on our side."
    return render_template("error.html", code=code, message=message), code


if __name__ == "__main__":
    # debug=False: the debugger lets anyone run code on your machine.
    app.run(host="127.0.0.1", port=5000, debug=False)
