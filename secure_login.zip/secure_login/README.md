# Secure Login System (Flask + SQLite)

## 1. Folder structure
```
secure_login/
├── app.py            # routes, validation, CSRF, rate limiting
├── config.py         # settings (secret key, cookies, limits)
├── db.py             # SQLite connection + auto table creation
├── schema.sql        # users + login_attempts tables
├── test_app.py       # 15 automated tests
├── requirements.txt
├── .gitignore
├── templates/        # base, register, login, dashboard, error
├── static/css/style.css
├── static/js/app.js
└── instance/         # created automatically (holds the .db file)
```

## 2. Setup (Windows, PowerShell)
```
cd secure_login
python -m venv venv
venv\Scripts\Activate.ps1
pip install -r requirements.txt
```
(If activation is blocked: `Set-ExecutionPolicy -Scope Process RemoteSigned`. In Command Prompt use `venv\Scripts\activate.bat`.)

## 2. Setup (Linux / macOS)
```
cd secure_login
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 3. Generate a secret key
```
python -c "import secrets; print(secrets.token_hex(32))"
```
Set it as an environment variable (same terminal you run the app in):

- Windows PowerShell: `$env:SECRET_KEY="paste-key-here"`
- Windows CMD: `set SECRET_KEY=paste-key-here`
- Linux/macOS: `export SECRET_KEY="paste-key-here"`

Never put the key in code or upload it to GitHub.

## 4. Run
- Windows: `python app.py`
- Linux/macOS: `python3 app.py`

Open http://127.0.0.1:5000 in your browser. Stop with Ctrl+C.
The database is created automatically at `instance/secure_login.db`.

## 5. Run automated tests
`python -m unittest -v`  (use `python3` on Linux/macOS)

## 6. Manual test cases
| # | Test | Steps | Expected result |
|---|------|-------|-----------------|
| 1 | Register OK | /register → `alice_01` / `Str0ng!Pass1` / same confirm | Green "Account created", redirected to login |
| 2 | Weak password | Register `bob` with `password` | Red list of missing rules; no account |
| 3 | Mismatch | Different confirm password | "Passwords do not match." |
| 4 | Bad username | `bad name!` | Username rule error |
| 5 | Duplicate | Register `alice_01` again (or `ALICE_01`) | "That username is already taken." |
| 6 | Login OK | Log in as `alice_01` | Dashboard: "Welcome, alice_01!" |
| 7 | Wrong password | Right user, wrong password | "Invalid username or password." |
| 8 | Unknown user | Username that doesn't exist | The same generic message |
| 9 | Lockout | 5 wrong passwords in a row | "Too many failed attempts. Try again in about 5 minute(s)." even with correct password |
| 10 | Logout | Click Log out | Back at login with "logged out" message |
| 11 | After logout | Press browser Back / open /dashboard | Redirected to login |
| 12 | Unauthorized | New private window → /dashboard | Redirected to login, "Please log in" |
| 13 | SQL injection | Username `' OR '1'='1' --`, any password | "Invalid username or password." |
| 14 | CSRF | In DevTools delete the hidden `csrf_token` input, submit | "Error 400 – Invalid or missing CSRF token" |
| 15 | Hashing | `sqlite3 instance/secure_login.db "SELECT username,password_hash FROM users;"` | Hash starting with `scrypt:`, never the password |

To reset a lockout during a demo, wait 5 minutes or delete `instance/secure_login.db`.

## 7. Production notes
Local demo uses HTTP. For real deployment: use HTTPS, set `SESSION_COOKIE_SECURE=true`, run with a production server (gunicorn/waitress), never `debug=True`.
