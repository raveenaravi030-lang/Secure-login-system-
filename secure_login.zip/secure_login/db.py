"""Database helpers: one connection per request, closed automatically."""
import os
import sqlite3

from flask import current_app, g


def get_db():
    """Return this request's SQLite connection (create it on first use)."""
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row            # access columns by name
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(error=None):
    """Close the connection when the request ends (even if an error happened)."""
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db(app):
    """Create the database file and tables if they do not exist yet."""
    db_path = app.config["DATABASE"]
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    with sqlite3.connect(db_path) as conn, open(schema_path, encoding="utf-8") as f:
        conn.executescript(f.read())
    app.teardown_appcontext(close_db)
