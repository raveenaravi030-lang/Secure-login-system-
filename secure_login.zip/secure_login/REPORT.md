# Cybersecurity Mini Project Report
## Secure Login System using Python, Flask and SQLite

### 1. Abstract
Weak authentication is one of the most common causes of web-application breaches. This project builds a secure user registration and login system using Python, Flask, SQLite, HTML and CSS. It demonstrates core defences: salted password hashing, parameterized SQL queries, CSRF tokens, hardened session cookies, brute-force lockout, input validation, security headers and access control on protected pages. The system was verified with 15 automated tests and a manual test plan.

### 2. Objectives
1. Let users register and log in with a username and password.
2. Never store plain-text passwords; hash them with Werkzeug.
3. Prevent SQL injection, CSRF, session theft and brute-force guessing.
4. Restrict the dashboard to authenticated users and provide secure logout.
5. Provide a clean, responsive interface suitable for demonstration.

### 3. Technologies Used
| Technology | Purpose |
|---|---|
| Python 3 | Programming language |
| Flask | Web framework, routing, sessions, templates |
| Werkzeug | `generate_password_hash`, `check_password_hash` (scrypt + salt) |
| SQLite | Embedded database |
| HTML / CSS / small JS | Pages, responsive styling, password-strength meter |
| unittest | Automated testing |

### 4. System Design
**Architecture:** Browser → Flask routes (`app.py`) → SQLite (`db.py`).

**Database**
- `users(id, username UNIQUE NOCASE, password_hash, created_at)`
- `login_attempts(id, username, ip_address, attempted_at)`

**Routes**
| Route | Method | Access | Purpose |
|---|---|---|---|
| `/` | GET | Public | Redirect to dashboard or login |
| `/register` | GET, POST | Public | Create account |
| `/login` | GET, POST | Public | Authenticate |
| `/dashboard` | GET | Logged-in only | Welcome page |
| `/logout` | POST | Logged-in | End session |

**Login flow:** check lockout → look up user (parameterized query) → verify hash (dummy hash if user unknown) → on success clear old session, store `user_id`, redirect; on failure record attempt and show generic error.

### 5. Implementation
- **Validation:** username 3–20 chars of letters, digits, underscore; password 8–128 chars with upper, lower, digit, special, not containing the username; confirmation must match. Checks run on the server (browser checks are only for convenience).
- **Registration:** password hashed with `generate_password_hash`; the INSERT uses `?` placeholders; the UNIQUE (case-insensitive) constraint rejects duplicates.
- **Login:** `check_password_hash` compares the input with the stored hash. `session.clear()` then `session['user_id']` is set.
- **Dashboard:** `@login_required` decorator reloads the user from the database on each request; otherwise redirects to login.
- **Database handling:** one connection per request stored in `flask.g` and closed in a teardown handler; tables are created automatically at startup from `schema.sql`.

### 6. Security Features
| Threat | Defence | How it works |
|---|---|---|
| Password database leak | Salted scrypt hashing | Only a one-way hash with a random salt is stored; identical passwords produce different hashes |
| SQL injection | Parameterized queries | Input is passed separately from the SQL text, so it is always treated as data |
| CSRF | Per-session random token | Every POST form carries a hidden token compared (constant-time) with the session copy; forged cross-site requests lack it |
| Session theft / tampering | Signed cookie, `HttpOnly`, `SameSite=Lax`, optional `Secure`, 30-min lifetime | JS cannot read the cookie; cross-site POSTs don't send it; it is signed with `SECRET_KEY` |
| Session fixation | `session.clear()` at login | A fresh session is issued after authentication |
| Brute force | 5 failures / 5 min lockout per username + IP | Failed attempts are logged in SQLite; further attempts get HTTP 429 |
| User enumeration | Generic error + dummy hash check | Same message and similar timing for unknown user and wrong password |
| Unauthorized access | `@login_required` | Server checks the session on every protected request |
| Forced logout by other sites | POST-only logout with CSRF | A simple link or image cannot log the user out |
| XSS / clickjacking | Jinja2 auto-escaping, CSP, `X-Frame-Options: DENY`, `nosniff` | Output is escaped; only same-origin scripts/styles run; the site cannot be framed |
| Stale pages after logout | `Cache-Control: no-store` | Back button doesn't reveal dashboard |
| Information leakage | Custom error pages, `debug=False` | No stack traces shown |

### 7. Test Cases
Automated (`python -m unittest -v`) – all 15 pass:
register success; duplicate username (case-insensitive); weak password; invalid username; password mismatch; password stored hashed; login + dashboard; wrong password; unknown user; dashboard blocked when logged out; logout; CSRF rejection; SQL-injection attempt; lockout after 5 failures; cookie flags.
Manual cases are in `README.md` (section 6).

### 8. Limitations
- Runs on HTTP locally; real deployments need HTTPS (and `SESSION_COOKIE_SECURE=true`).
- Registration reveals whether a username is taken (user enumeration); a production system would often use email verification.
- Lockout is per username+IP, so an attacker rotating IPs can still try; behind a proxy `request.remote_addr` needs proxy configuration. Locking by username alone would allow denial-of-service against a victim.
- No multi-factor authentication, email verification or password reset.
- No account/password change page; no audit logging.
- SQLite is suited to demos, not high-traffic sites.
- CSRF is hand-written for learning; production projects usually use Flask-WTF.
- Sessions are client-side signed cookies, so a server-side revoke list is not available.

### 9. Conclusion
The project shows that a login system can be made substantially more secure using standard, well-understood techniques available in Flask and Werkzeug. Hashing, parameterized queries, CSRF tokens, cookie hardening, rate limiting and access control together defend against the most common web-authentication attacks. Future work: HTTPS deployment, MFA, email verification, password reset and Flask-Limiter with Redis.
