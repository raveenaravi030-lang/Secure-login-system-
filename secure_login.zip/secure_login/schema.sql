-- Created automatically on first run by db.py

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    NOT NULL UNIQUE COLLATE NOCASE,  -- "Alice" == "alice"
    password_hash TEXT    NOT NULL,                        -- never the real password
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS login_attempts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    username     TEXT    NOT NULL,
    ip_address   TEXT    NOT NULL,
    attempted_at INTEGER NOT NULL                          -- unix timestamp
);

CREATE INDEX IF NOT EXISTS idx_attempts_lookup
    ON login_attempts (username, ip_address, attempted_at);
