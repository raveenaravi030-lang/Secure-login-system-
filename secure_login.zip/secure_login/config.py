"""Configuration for the Secure Login System.

Settings come from environment variables so that secrets are never
hard-coded in source code.
"""
import os
import secrets

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


def _env_bool(name, default=False):
    return os.environ.get(name, str(default)).strip().lower() in ("1", "true", "yes")


# --- Secret key (signs the session cookie) -------------------------------
SECRET_KEY = os.environ.get("SECRET_KEY")
if not SECRET_KEY:
    # Fallback so the demo still runs. A random key changes on every restart,
    # which logs everybody out. Set SECRET_KEY properly (see README).
    SECRET_KEY = secrets.token_hex(32)
    print("[WARNING] SECRET_KEY is not set. Using a temporary random key.")

# --- Database -------------------------------------------------------------
DATABASE = os.environ.get(
    "DATABASE_PATH", os.path.join(BASE_DIR, "instance", "secure_login.db")
)

# --- Session cookie hardening --------------------------------------------
SESSION_COOKIE_HTTPONLY = True      # JavaScript cannot read the cookie (anti-XSS theft)
SESSION_COOKIE_SAMESITE = "Lax"     # Cookie not sent on cross-site POSTs (anti-CSRF)
# Secure=True means "send only over HTTPS". Turn on when deploying with HTTPS.
SESSION_COOKIE_SECURE = _env_bool("SESSION_COOKIE_SECURE", False)
SESSION_COOKIE_NAME = "secure_login_session"
PERMANENT_SESSION_LIFETIME = 30 * 60  # session expires after 30 minutes

# --- Request size limit ---------------------------------------------------
MAX_CONTENT_LENGTH = 16 * 1024  # 16 KB is plenty for a login form

# --- Brute-force protection ----------------------------------------------
MAX_FAILED_ATTEMPTS = 5        # failures allowed...
LOCKOUT_SECONDS = 5 * 60       # ...within this window, otherwise locked out

# --- Input rules ----------------------------------------------------------
USERNAME_MIN, USERNAME_MAX = 3, 20
PASSWORD_MIN, PASSWORD_MAX = 8, 128
