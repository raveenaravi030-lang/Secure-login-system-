"""Automated tests. Run with:  python -m unittest -v"""
import os
import re
import tempfile
import unittest

# Use a throw-away database so tests never touch real data
_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
os.environ["DATABASE_PATH"] = _tmp.name
os.environ["SECRET_KEY"] = "test-secret-key"

from app import app  # noqa: E402

GOOD_PW = "Str0ng!Passw0rd"


def token_from(html):
    return re.search(r'name="csrf_token" value="([a-f0-9]+)"', html).group(1)


class SecureLoginTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def get_token(self, path):
        return token_from(self.client.get(path).get_data(as_text=True))

    def register(self, user="alice", pw=GOOD_PW, confirm=None):
        return self.client.post("/register", data={
            "csrf_token": self.get_token("/register"), "username": user,
            "password": pw, "confirm_password": pw if confirm is None else confirm})

    def login(self, user="alice", pw=GOOD_PW):
        return self.client.post("/login", data={
            "csrf_token": self.get_token("/login"), "username": user, "password": pw})

    def test_01_register_success(self):
        r = self.register("alice")
        self.assertEqual(r.status_code, 302)

    def test_02_duplicate_username(self):
        self.register("bob")
        r = self.register("BOB")           # case-insensitive duplicate
        self.assertEqual(r.status_code, 409)
        self.assertIn("already taken", r.get_data(as_text=True))

    def test_03_weak_password_rejected(self):
        r = self.register("carol", pw="password")
        self.assertEqual(r.status_code, 400)

    def test_04_invalid_username_rejected(self):
        r = self.register("bad name!")
        self.assertEqual(r.status_code, 400)

    def test_05_password_mismatch(self):
        r = self.register("dave", confirm="Different1!")
        self.assertEqual(r.status_code, 400)

    def test_06_password_is_hashed(self):
        import sqlite3
        self.register("erin")
        row = sqlite3.connect(os.environ["DATABASE_PATH"]).execute(
            "SELECT password_hash FROM users WHERE username='erin'").fetchone()
        self.assertNotIn(GOOD_PW, row[0])
        self.assertTrue(row[0].startswith(("scrypt:", "pbkdf2:")))

    def test_07_login_success_and_dashboard(self):
        self.register("frank")
        self.assertEqual(self.login("frank").status_code, 302)
        r = self.client.get("/dashboard")
        self.assertEqual(r.status_code, 200)
        self.assertIn("Welcome, frank!", r.get_data(as_text=True))

    def test_08_wrong_password_generic_error(self):
        self.register("gina")
        r = self.login("gina", "WrongPass1!")
        self.assertEqual(r.status_code, 401)
        self.assertIn("Invalid username or password.", r.get_data(as_text=True))

    def test_09_unknown_user_same_error(self):
        r = self.login("nobody_here", "Whatever1!")
        self.assertEqual(r.status_code, 401)
        self.assertIn("Invalid username or password.", r.get_data(as_text=True))

    def test_10_dashboard_requires_login(self):
        r = self.client.get("/dashboard")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])

    def test_11_logout(self):
        self.register("hank")
        self.login("hank")
        token = self.get_token("/dashboard")
        self.assertEqual(self.client.post("/logout", data={"csrf_token": token}).status_code, 302)
        self.assertEqual(self.client.get("/dashboard").status_code, 302)

    def test_12_csrf_blocks_post_without_token(self):
        r = self.client.post("/login", data={"username": "a", "password": "b"})
        self.assertEqual(r.status_code, 400)

    def test_13_sql_injection_fails(self):
        self.register("ivan")
        r = self.login("' OR '1'='1' --", "anything")
        self.assertEqual(r.status_code, 401)

    def test_14_lockout_after_repeated_failures(self):
        self.register("judy")
        for _ in range(5):
            self.login("judy", "WrongPass1!")
        r = self.login("judy", GOOD_PW)    # even the correct password is blocked
        self.assertEqual(r.status_code, 429)

    def test_15_cookie_flags(self):
        r = self.client.get("/login")
        cookie = r.headers.get("Set-Cookie", "")
        self.assertIn("HttpOnly", cookie)
        self.assertIn("SameSite=Lax", cookie)


if __name__ == "__main__":
    unittest.main()
